package datos;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/** Conexion a SQLite. La base es el archivo tienda.db en la carpeta del proyecto. */
public final class Conexion {

    private static final String URL = "jdbc:sqlite:tienda.db";

    private Conexion() {
    }

    public static Connection getConexion() throws SQLException {
        Connection con = DriverManager.getConnection(URL);
        try (Statement st = con.createStatement()) {
            // SQLite no hace cumplir las llaves foraneas (ni el CASCADE) si no se activan.
            st.execute("PRAGMA foreign_keys = ON");
        }
        return con;
    }

    public static String getUrl() {
        return URL;
    }

    /** Lee una columna monetaria como BigDecimal con 2 decimales. */
    public static BigDecimal leerDinero(ResultSet rs, int columna) throws SQLException {
        String texto = rs.getString(columna);
        if (texto == null) {
            return BigDecimal.ZERO.setScale(2);
        }
        return new BigDecimal(texto).setScale(2, RoundingMode.HALF_UP);
    }

    /** Crea las tablas si no existen y, la primera vez, carga los datos de ejemplo. */
    public static void inicializar() throws SQLException {
        try (Connection con = getConexion(); Statement st = con.createStatement()) {
            st.execute("CREATE TABLE IF NOT EXISTS usuarios ("
                    + "id_usuario INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "nombre TEXT NOT NULL, "
                    + "correo TEXT NOT NULL UNIQUE, "
                    + "rol TEXT NOT NULL)");
            st.execute("CREATE TABLE IF NOT EXISTS productos ("
                    + "id_producto INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "codigo TEXT NOT NULL UNIQUE, "
                    + "nombre TEXT NOT NULL, "
                    + "unidad_medida TEXT NOT NULL, "
                    + "precio NUMERIC NOT NULL CHECK (precio >= 0), "
                    + "stock_actual INTEGER NOT NULL CHECK (stock_actual >= 0), "
                    + "stock_minimo INTEGER NOT NULL DEFAULT 5 CHECK (stock_minimo >= 0))");
            st.execute("CREATE TABLE IF NOT EXISTS ventas ("
                    + "id_venta INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "id_usuario INTEGER REFERENCES usuarios(id_usuario), "
                    + "fecha_venta TEXT DEFAULT (datetime('now','localtime')), "
                    + "total_venta NUMERIC NOT NULL CHECK (total_venta >= 0))");
            st.execute("CREATE TABLE IF NOT EXISTS inventario ("
                    + "id_inventario INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "id_venta INTEGER REFERENCES ventas(id_venta) ON DELETE CASCADE, "
                    + "id_producto INTEGER REFERENCES productos(id_producto), "
                    + "cantidad INTEGER NOT NULL CHECK (cantidad > 0), "
                    + "subtotal NUMERIC NOT NULL CHECK (subtotal >= 0), "
                    + "fecha_movimiento TEXT DEFAULT (datetime('now','localtime')))");

            boolean vacia;
            try (ResultSet rs = st.executeQuery(
                    "SELECT (SELECT COUNT(*) FROM usuarios) + (SELECT COUNT(*) FROM productos)")) {
                vacia = rs.next() && rs.getInt(1) == 0;
            }
            if (vacia) {
                st.execute("INSERT INTO usuarios (nombre, correo, rol) VALUES "
                        + "('Yarith Sofía Gómez', 'ysofiagomez@uts.edu.co', 'Administrador'), "
                        + "('Leonel Stiben Guarín', 'lstibenguarin@uts.edu.co', 'Cajero'), "
                        + "('Andrés Camilo Guevara', 'andrescguevara@uts.edu.co', 'Inventarios')");
                st.execute("INSERT INTO productos (codigo, nombre, unidad_medida, precio, stock_actual, stock_minimo) VALUES "
                        + "('P001', 'Arroz Diana', '1 kg', 2500.00, 25, 5), "
                        + "('P002', 'Aceite Girasol', '1 Litro', 8000.00, 12, 4), "
                        + "('P003', 'Panela Redonda', '1 Unidad', 6000.00, 3, 5), "
                        + "('P004', 'Leche Entera', '1 Litro', 4000.00, 18, 6), "
                        + "('P005', 'Huevos AA', '30 und', 12000.00, 4, 5)");
                st.execute("INSERT INTO ventas (id_usuario, total_venta) VALUES (2, 16000.00)");
                st.execute("INSERT INTO inventario (id_venta, id_producto, cantidad, subtotal) VALUES "
                        + "(1, 2, 1, 8000.00), (1, 4, 2, 8000.00)");
            }
        }
    }
}
