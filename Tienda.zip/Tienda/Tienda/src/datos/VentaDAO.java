package datos;

import modelo.DetalleVenta;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class VentaDAO {

    /**
     * Registra la venta y sus lineas en una sola transaccion y descuenta el stock.
     * El precio se toma de la base de datos y se valida el stock disponible.
     * @return el id de la venta creada
     */
    public int registrar(int idUsuario, List<DetalleVenta> detalles) throws SQLException {
        try (Connection con = Conexion.getConexion()) {
            con.setAutoCommit(false);
            try {
                BigDecimal total = BigDecimal.ZERO;
                List<BigDecimal> subtotales = new ArrayList<>();

                String sqlBloqueo = "SELECT nombre, precio, stock_actual FROM productos "
                        + "WHERE id_producto = ?";
                try (PreparedStatement ps = con.prepareStatement(sqlBloqueo)) {
                    for (DetalleVenta d : detalles) {
                        ps.setInt(1, d.getProducto().getId());
                        try (ResultSet rs = ps.executeQuery()) {
                            if (!rs.next()) {
                                throw new SQLException("El producto " + d.getProducto().getNombre() + " ya no existe.");
                            }
                            if (rs.getInt("stock_actual") < d.getCantidad()) {
                                throw new SQLException("Stock insuficiente de " + rs.getString("nombre")
                                        + " (disponible: " + rs.getInt("stock_actual") + ").");
                            }
                            BigDecimal sub = Conexion.leerDinero(rs, 2).multiply(BigDecimal.valueOf(d.getCantidad()));
                            subtotales.add(sub);
                            total = total.add(sub);
                        }
                    }
                }

                int idVenta;
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO ventas (id_usuario, total_venta) VALUES (?, ?)")) {
                    ps.setInt(1, idUsuario);
                    ps.setDouble(2, total.doubleValue());
                    ps.executeUpdate();
                }
                try (Statement st = con.createStatement();
                     ResultSet rs = st.executeQuery("SELECT last_insert_rowid()")) {
                    rs.next();
                    idVenta = rs.getInt(1);
                }

                try (PreparedStatement psInv = con.prepareStatement(
                        "INSERT INTO inventario (id_venta, id_producto, cantidad, subtotal) VALUES (?, ?, ?, ?)");
                     PreparedStatement psStock = con.prepareStatement(
                        "UPDATE productos SET stock_actual = stock_actual - ? WHERE id_producto = ?")) {
                    for (int i = 0; i < detalles.size(); i++) {
                        DetalleVenta d = detalles.get(i);
                        psInv.setInt(1, idVenta);
                        psInv.setInt(2, d.getProducto().getId());
                        psInv.setInt(3, d.getCantidad());
                        psInv.setDouble(4, subtotales.get(i).doubleValue());
                        psInv.executeUpdate();

                        psStock.setInt(1, d.getCantidad());
                        psStock.setInt(2, d.getProducto().getId());
                        psStock.executeUpdate();
                    }
                }
                con.commit();
                return idVenta;
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        }
    }

    /** Filas: id, cajero, fecha, total. */
    public List<Object[]> listar() throws SQLException {
        List<Object[]> filas = new ArrayList<>();
        String sql = "SELECT v.id_venta, COALESCE(u.nombre, '(sin usuario)'), v.fecha_venta, v.total_venta "
                + "FROM ventas v LEFT JOIN usuarios u ON u.id_usuario = v.id_usuario "
                + "ORDER BY v.id_venta DESC";
        try (Connection con = Conexion.getConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                filas.add(new Object[]{rs.getInt(1), rs.getString(2), rs.getString(3), Conexion.leerDinero(rs, 4)});
            }
        }
        return filas;
    }

    /** Filas: codigo, producto, cantidad, subtotal. */
    public List<Object[]> detalle(int idVenta) throws SQLException {
        List<Object[]> filas = new ArrayList<>();
        String sql = "SELECT p.codigo, p.nombre, i.cantidad, i.subtotal FROM inventario i "
                + "JOIN productos p ON p.id_producto = i.id_producto WHERE i.id_venta = ? ORDER BY i.id_inventario";
        try (Connection con = Conexion.getConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idVenta);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    filas.add(new Object[]{rs.getString(1), rs.getString(2), rs.getInt(3), Conexion.leerDinero(rs, 4)});
                }
            }
        }
        return filas;
    }

    /** Anula una venta: devuelve el stock y borra la venta (sus lineas caen por CASCADE). */
    public void anular(int idVenta) throws SQLException {
        try (Connection con = Conexion.getConexion()) {
            con.setAutoCommit(false);
            try {
                try (PreparedStatement sel = con.prepareStatement(
                        "SELECT id_producto, cantidad FROM inventario WHERE id_venta = ?");
                     PreparedStatement upd = con.prepareStatement(
                        "UPDATE productos SET stock_actual = stock_actual + ? WHERE id_producto = ?")) {
                    sel.setInt(1, idVenta);
                    try (ResultSet rs = sel.executeQuery()) {
                        while (rs.next()) {
                            upd.setInt(1, rs.getInt("cantidad"));
                            upd.setInt(2, rs.getInt("id_producto"));
                            upd.executeUpdate();
                        }
                    }
                }
                try (PreparedStatement del = con.prepareStatement("DELETE FROM ventas WHERE id_venta = ?")) {
                    del.setInt(1, idVenta);
                    del.executeUpdate();
                }
                con.commit();
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        }
    }
}
