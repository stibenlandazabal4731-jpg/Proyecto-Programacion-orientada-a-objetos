package datos;

import modelo.Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {

    private static final String COLUMNAS =
            "SELECT id_producto, codigo, nombre, unidad_medida, precio, stock_actual, stock_minimo FROM productos ";

    private Producto mapear(ResultSet rs) throws SQLException {
        return new Producto(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
                Conexion.leerDinero(rs, 5), rs.getInt(6), rs.getInt(7));
    }

    private List<Producto> consultar(String sql) throws SQLException {
        List<Producto> lista = new ArrayList<>();
        try (Connection con = Conexion.getConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    public List<Producto> listar() throws SQLException {
        return consultar(COLUMNAS + "ORDER BY id_producto");
    }

    /** Productos cuyo stock actual es menor o igual al minimo. */
    public List<Producto> stockBajo() throws SQLException {
        return consultar(COLUMNAS + "WHERE stock_actual <= stock_minimo ORDER BY nombre");
    }

    public void crear(Producto p) throws SQLException {
        String sql = "INSERT INTO productos (codigo, nombre, unidad_medida, precio, stock_actual, stock_minimo) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = Conexion.getConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getCodigo());
            ps.setString(2, p.getNombre());
            ps.setString(3, p.getUnidadMedida());
            ps.setDouble(4, p.getPrecio().doubleValue());
            ps.setInt(5, p.getStockActual());
            ps.setInt(6, p.getStockMinimo());
            ps.executeUpdate();
        }
    }

    public void actualizar(Producto p) throws SQLException {
        String sql = "UPDATE productos SET codigo = ?, nombre = ?, unidad_medida = ?, precio = ?, "
                + "stock_actual = ?, stock_minimo = ? WHERE id_producto = ?";
        try (Connection con = Conexion.getConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getCodigo());
            ps.setString(2, p.getNombre());
            ps.setString(3, p.getUnidadMedida());
            ps.setDouble(4, p.getPrecio().doubleValue());
            ps.setInt(5, p.getStockActual());
            ps.setInt(6, p.getStockMinimo());
            ps.setInt(7, p.getId());
            ps.executeUpdate();
        }
    }

    public void eliminar(int id) throws SQLException {
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement("DELETE FROM productos WHERE id_producto = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
