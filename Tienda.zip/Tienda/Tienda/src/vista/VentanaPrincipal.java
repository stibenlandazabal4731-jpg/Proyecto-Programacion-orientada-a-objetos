package vista;

import datos.Conexion;
import datos.ProductoDAO;
import modelo.Producto;
import java.awt.Dimension;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

/** Ventana principal con el menu de la aplicacion. */
public class VentanaPrincipal extends JFrame {

    private final JDesktopPane escritorio = new JDesktopPane();
    private FrmProductos frmProductos;
    private FrmUsuarios frmUsuarios;
    private FrmVentas frmVentas;

    public VentanaPrincipal() {
        super("Tienda - Gestión de inventario y ventas");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 680);
        setLocationRelativeTo(null);
        setContentPane(escritorio);
        setJMenuBar(crearMenu());
    }

    private JMenuBar crearMenu() {
        JMenu mArchivo = new JMenu("Archivo");
        mArchivo.setMnemonic(KeyEvent.VK_A);
        JMenuItem miProbar = new JMenuItem("Probar conexión");
        JMenuItem miSalir = new JMenuItem("Salir");
        miSalir.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, InputEvent.CTRL_DOWN_MASK));
        miProbar.addActionListener(e -> probarConexion());
        miSalir.addActionListener(e -> salir());
        mArchivo.add(miProbar);
        mArchivo.addSeparator();
        mArchivo.add(miSalir);

        JMenu mGestion = new JMenu("Gestión");
        mGestion.setMnemonic(KeyEvent.VK_G);
        JMenuItem miProductos = new JMenuItem("Productos");
        JMenuItem miUsuarios = new JMenuItem("Usuarios");
        JMenuItem miVentas = new JMenuItem("Ventas");
        miProductos.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, InputEvent.CTRL_DOWN_MASK));
        miUsuarios.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_U, InputEvent.CTRL_DOWN_MASK));
        miVentas.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, InputEvent.CTRL_DOWN_MASK));
        miProductos.addActionListener(e -> abrirProductos());
        miUsuarios.addActionListener(e -> abrirUsuarios());
        miVentas.addActionListener(e -> abrirVentas());
        mGestion.add(miProductos);
        mGestion.add(miUsuarios);
        mGestion.add(miVentas);

        JMenu mReportes = new JMenu("Reportes");
        mReportes.setMnemonic(KeyEvent.VK_R);
        JMenuItem miStock = new JMenuItem("Productos con stock bajo");
        miStock.addActionListener(e -> mostrarStockBajo());
        mReportes.add(miStock);

        JMenu mAyuda = new JMenu("Ayuda");
        JMenuItem miAcerca = new JMenuItem("Acerca de");
        miAcerca.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Tienda - CRUD de productos, usuarios y ventas\nJava Swing + SQLite (JDBC)",
                "Acerca de", JOptionPane.INFORMATION_MESSAGE));
        mAyuda.add(miAcerca);

        JMenuBar barra = new JMenuBar();
        barra.add(mArchivo);
        barra.add(mGestion);
        barra.add(mReportes);
        barra.add(mAyuda);
        return barra;
    }

    private void abrirProductos() {
        if (frmProductos == null || frmProductos.isClosed()) {
            frmProductos = new FrmProductos();
            escritorio.add(frmProductos);
            frmProductos.setLocation(20, 20);
        }
        mostrar(frmProductos);
    }

    private void abrirUsuarios() {
        if (frmUsuarios == null || frmUsuarios.isClosed()) {
            frmUsuarios = new FrmUsuarios();
            escritorio.add(frmUsuarios);
            frmUsuarios.setLocation(60, 60);
        }
        mostrar(frmUsuarios);
    }

    private void abrirVentas() {
        if (frmVentas == null || frmVentas.isClosed()) {
            frmVentas = new FrmVentas();
            escritorio.add(frmVentas);
            frmVentas.setLocation(100, 40);
        }
        mostrar(frmVentas);
    }

    private void mostrar(JInternalFrame f) {
        f.setVisible(true);
        try {
            f.setIcon(false);
            f.setSelected(true);
        } catch (PropertyVetoException ex) {
            // Se ignora: la ventana igual queda visible.
        }
        f.toFront();
    }

    private void probarConexion() {
        try (Connection con = Conexion.getConexion()) {
            JOptionPane.showMessageDialog(this, "Conexión exitosa a:\n" + Conexion.getUrl(),
                    "Conexión", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            Ui.error(this, Ui.mensajeSQL(ex) + "\n\nURL: " + Conexion.getUrl());
        }
    }

    private void mostrarStockBajo() {
        try {
            List<Producto> bajos = new ProductoDAO().stockBajo();
            if (bajos.isEmpty()) {
                Ui.info(this, "Todos los productos tienen stock suficiente.");
                return;
            }
            DefaultTableModel modelo = Ui.modelo("Código", "Producto", "Stock", "Mínimo");
            for (Producto p : bajos) {
                modelo.addRow(new Object[]{p.getCodigo(), p.getNombre(), p.getStockActual(), p.getStockMinimo()});
            }
            JScrollPane scroll = new JScrollPane(new JTable(modelo));
            scroll.setPreferredSize(new Dimension(460, 200));
            JOptionPane.showMessageDialog(this, scroll, "Productos con stock bajo",
                    JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            Ui.error(this, Ui.mensajeSQL(ex));
        }
    }

    private void salir() {
        if (Ui.confirmar(this, "¿Cerrar la aplicación?")) {
            dispose();
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            // Se queda con el aspecto por defecto.
        }
        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal ventana = new VentanaPrincipal();
            ventana.setVisible(true);
            try {
                Conexion.inicializar();
            } catch (SQLException ex) {
                Ui.error(ventana, "No se pudo abrir la base de datos.\n" + Ui.mensajeSQL(ex)
                        + "\n\nURL: " + Conexion.getUrl());
            }
        });
    }
}
