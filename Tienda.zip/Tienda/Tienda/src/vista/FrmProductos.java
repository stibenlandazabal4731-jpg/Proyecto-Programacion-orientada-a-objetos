package vista;

import datos.ProductoDAO;
import modelo.Producto;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

/** CRUD de productos. Las filas con stock bajo se pintan en rojo. */
public class FrmProductos extends JInternalFrame {

    private final ProductoDAO dao = new ProductoDAO();
    private List<Producto> datos = new ArrayList<>();

    private final JTextField txtId = new JTextField();
    private final JTextField txtCodigo = new JTextField(12);
    private final JTextField txtNombre = new JTextField(20);
    private final JTextField txtUnidad = new JTextField(12);
    private final JTextField txtPrecio = new JTextField(10);
    private final JSpinner spnStock = new JSpinner(new SpinnerNumberModel(0, 0, 1000000, 1));
    private final JSpinner spnMinimo = new JSpinner(new SpinnerNumberModel(5, 0, 1000000, 1));

    private final DefaultTableModel modelo = Ui.modelo(
            "ID", "Código", "Nombre", "Unidad", "Precio", "Stock", "Stock mín.");
    private final JTable tabla = new JTable(modelo) {
        @Override
        public Component prepareRenderer(TableCellRenderer r, int fila, int col) {
            Component c = super.prepareRenderer(r, fila, col);
            if (!isRowSelected(fila)) {
                int stock = (Integer) getValueAt(fila, 5);
                int minimo = (Integer) getValueAt(fila, 6);
                c.setForeground(stock <= minimo ? new Color(180, 30, 30) : UIManager.getColor("Table.foreground"));
            }
            return c;
        }
    };

    public FrmProductos() {
        super("Gestión de productos", true, true, true, true);
        txtId.setEditable(false);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Datos del producto"));
        Ui.fila(form, 0, "ID:", txtId);
        Ui.fila(form, 1, "Código (máx. 10):", txtCodigo);
        Ui.fila(form, 2, "Nombre:", txtNombre);
        Ui.fila(form, 3, "Unidad de medida:", txtUnidad);
        Ui.fila(form, 4, "Precio:", txtPrecio);
        Ui.fila(form, 5, "Stock actual:", spnStock);
        Ui.fila(form, 6, "Stock mínimo:", spnMinimo);

        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.getSelectionModel().addListSelectionListener(e -> {
            int fila = tabla.getSelectedRow();
            if (!e.getValueIsAdjusting() && fila >= 0 && fila < datos.size()) {
                mostrar(datos.get(fila));
            }
        });
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createTitledBorder("Listado (en rojo: stock bajo)"));

        JButton btnNuevo = new JButton("Nuevo");
        JButton btnGuardar = new JButton("Guardar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnRefrescar = new JButton("Refrescar");
        btnNuevo.addActionListener(e -> limpiar());
        btnGuardar.addActionListener(e -> guardar());
        btnEliminar.addActionListener(e -> eliminar());
        btnRefrescar.addActionListener(e -> cargar());
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 6));
        botones.add(btnNuevo);
        botones.add(btnGuardar);
        botones.add(btnEliminar);
        botones.add(btnRefrescar);

        add(form, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(botones, BorderLayout.SOUTH);
        setSize(780, 560);
        cargar();
    }

    private void cargar() {
        try {
            datos = dao.listar();
            modelo.setRowCount(0);
            for (Producto p : datos) {
                modelo.addRow(new Object[]{p.getId(), p.getCodigo(), p.getNombre(), p.getUnidadMedida(),
                    Ui.dinero(p.getPrecio()), p.getStockActual(), p.getStockMinimo()});
            }
        } catch (SQLException ex) {
            Ui.error(this, Ui.mensajeSQL(ex));
        }
    }

    private void mostrar(Producto p) {
        txtId.setText(String.valueOf(p.getId()));
        txtCodigo.setText(p.getCodigo());
        txtNombre.setText(p.getNombre());
        txtUnidad.setText(p.getUnidadMedida());
        txtPrecio.setText(p.getPrecio().toPlainString());
        spnStock.setValue(p.getStockActual());
        spnMinimo.setValue(p.getStockMinimo());
    }

    private void limpiar() {
        tabla.clearSelection();
        txtId.setText("");
        txtCodigo.setText("");
        txtNombre.setText("");
        txtUnidad.setText("");
        txtPrecio.setText("");
        spnStock.setValue(0);
        spnMinimo.setValue(5);
        txtCodigo.requestFocus();
    }

    private Producto leer() {
        String codigo = txtCodigo.getText().trim();
        String nombre = txtNombre.getText().trim();
        String unidad = txtUnidad.getText().trim();
        if (codigo.isEmpty() || codigo.length() > 10) {
            throw new IllegalArgumentException("El código es obligatorio y tiene máximo 10 caracteres.");
        }
        if (nombre.isEmpty() || nombre.length() > 50) {
            throw new IllegalArgumentException("El nombre es obligatorio y tiene máximo 50 caracteres.");
        }
        if (unidad.isEmpty() || unidad.length() > 30) {
            throw new IllegalArgumentException("La unidad de medida es obligatoria (máx. 30 caracteres).");
        }
        BigDecimal precio;
        try {
            precio = new BigDecimal(txtPrecio.getText().trim().replace(",", "."));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("El precio debe ser un número, por ejemplo 2500 o 2500.50.");
        }
        if (precio.signum() < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo.");
        }
        Producto p = new Producto();
        p.setCodigo(codigo);
        p.setNombre(nombre);
        p.setUnidadMedida(unidad);
        p.setPrecio(precio.setScale(2, java.math.RoundingMode.HALF_UP));
        p.setStockActual(((Number) spnStock.getValue()).intValue());
        p.setStockMinimo(((Number) spnMinimo.getValue()).intValue());
        return p;
    }

    private void guardar() {
        try {
            Producto p = leer();
            if (txtId.getText().isEmpty()) {
                dao.crear(p);
            } else {
                p.setId(Integer.parseInt(txtId.getText()));
                dao.actualizar(p);
            }
            limpiar();
            cargar();
        } catch (IllegalArgumentException ex) {
            Ui.error(this, ex.getMessage());
        } catch (SQLException ex) {
            Ui.error(this, Ui.mensajeSQL(ex));
        }
    }

    private void eliminar() {
        if (txtId.getText().isEmpty()) {
            Ui.error(this, "Selecciona un producto de la tabla.");
            return;
        }
        if (!Ui.confirmar(this, "¿Eliminar el producto " + txtNombre.getText() + "?")) {
            return;
        }
        try {
            dao.eliminar(Integer.parseInt(txtId.getText()));
            limpiar();
            cargar();
        } catch (SQLException ex) {
            Ui.error(this, Ui.mensajeSQL(ex));
        }
    }
}
