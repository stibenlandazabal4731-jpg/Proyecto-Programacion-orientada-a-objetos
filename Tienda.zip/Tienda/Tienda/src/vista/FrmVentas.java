package vista;

import datos.ProductoDAO;
import datos.UsuarioDAO;
import datos.VentaDAO;
import modelo.DetalleVenta;
import modelo.Producto;
import modelo.Usuario;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

/** Registro de ventas (carrito) e historial con anulacion. */
public class FrmVentas extends JInternalFrame {

    private final ProductoDAO productoDAO = new ProductoDAO();
    private final UsuarioDAO usuarioDAO = new UsuarioDAO();
    private final VentaDAO ventaDAO = new VentaDAO();

    private final JComboBox<Usuario> cboUsuario = new JComboBox<>();
    private final JComboBox<Producto> cboProducto = new JComboBox<>();
    private final JSpinner spnCantidad = new JSpinner(new SpinnerNumberModel(1, 1, 100000, 1));
    private final List<DetalleVenta> carrito = new ArrayList<>();
    private final DefaultTableModel modeloCarrito = Ui.modelo("Código", "Producto", "Cant.", "Precio", "Subtotal");
    private final JTable tablaCarrito = new JTable(modeloCarrito);
    private final JLabel lblTotal = new JLabel("Total: $ 0.00");

    private final DefaultTableModel modeloVentas = Ui.modelo("ID", "Cajero", "Fecha", "Total");
    private final JTable tablaVentas = new JTable(modeloVentas);
    private final DefaultTableModel modeloDetalle = Ui.modelo("Código", "Producto", "Cant.", "Subtotal");
    private final JTable tablaDetalle = new JTable(modeloDetalle);

    public FrmVentas() {
        super("Ventas", true, true, true, true);
        JTabbedPane pestanas = new JTabbedPane();
        pestanas.addTab("Nueva venta", panelNuevaVenta());
        pestanas.addTab("Historial", panelHistorial());
        add(pestanas, BorderLayout.CENTER);
        setSize(820, 560);
        recargarCombos();
        cargarHistorial();
    }

    private JPanel panelNuevaVenta() {
        JPanel superior = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        superior.add(new JLabel("Cajero:"));
        superior.add(cboUsuario);
        superior.add(new JLabel("Producto:"));
        superior.add(cboProducto);
        superior.add(new JLabel("Cantidad:"));
        superior.add(spnCantidad);
        JButton btnAgregar = new JButton("Agregar");
        btnAgregar.addActionListener(e -> agregar());
        superior.add(btnAgregar);

        tablaCarrito.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(tablaCarrito);
        scroll.setBorder(BorderFactory.createTitledBorder("Productos de la venta"));

        JButton btnQuitar = new JButton("Quitar seleccionado");
        JButton btnRegistrar = new JButton("Registrar venta");
        btnQuitar.addActionListener(e -> quitar());
        btnRegistrar.addActionListener(e -> registrar());
        JPanel inferior = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 6));
        inferior.add(lblTotal);
        inferior.add(btnQuitar);
        inferior.add(btnRegistrar);

        JPanel p = new JPanel(new BorderLayout());
        p.add(superior, BorderLayout.NORTH);
        p.add(scroll, BorderLayout.CENTER);
        p.add(inferior, BorderLayout.SOUTH);
        return p;
    }

    private JPanel panelHistorial() {
        tablaVentas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaVentas.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                cargarDetalle();
            }
        });
        JScrollPane s1 = new JScrollPane(tablaVentas);
        s1.setBorder(BorderFactory.createTitledBorder("Ventas realizadas"));
        JScrollPane s2 = new JScrollPane(tablaDetalle);
        s2.setBorder(BorderFactory.createTitledBorder("Detalle de la venta seleccionada"));
        JPanel centro = new JPanel(new GridLayout(2, 1, 0, 6));
        centro.add(s1);
        centro.add(s2);

        JButton btnAnular = new JButton("Anular venta seleccionada");
        JButton btnRefrescar = new JButton("Refrescar");
        btnAnular.addActionListener(e -> anular());
        btnRefrescar.addActionListener(e -> cargarHistorial());
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 6));
        botones.add(btnAnular);
        botones.add(btnRefrescar);

        JPanel p = new JPanel(new BorderLayout());
        p.add(centro, BorderLayout.CENTER);
        p.add(botones, BorderLayout.SOUTH);
        return p;
    }

    private void recargarCombos() {
        try {
            cboUsuario.removeAllItems();
            for (Usuario u : usuarioDAO.listar()) {
                cboUsuario.addItem(u);
            }
            cboProducto.removeAllItems();
            for (Producto p : productoDAO.listar()) {
                cboProducto.addItem(p);
            }
        } catch (SQLException ex) {
            Ui.error(this, Ui.mensajeSQL(ex));
        }
    }

    private void agregar() {
        Producto p = (Producto) cboProducto.getSelectedItem();
        if (p == null) {
            Ui.error(this, "No hay productos disponibles.");
            return;
        }
        int cantidad = ((Number) spnCantidad.getValue()).intValue();
        DetalleVenta existente = null;
        for (DetalleVenta d : carrito) {
            if (d.getProducto().getId() == p.getId()) {
                existente = d;
            }
        }
        int yaEnCarrito = existente == null ? 0 : existente.getCantidad();
        if (yaEnCarrito + cantidad > p.getStockActual()) {
            Ui.error(this, "Stock insuficiente de " + p.getNombre() + ". Disponible: " + p.getStockActual()
                    + ", en esta venta: " + yaEnCarrito + ".");
            return;
        }
        if (existente == null) {
            carrito.add(new DetalleVenta(p, cantidad));
        } else {
            existente.setCantidad(yaEnCarrito + cantidad);
        }
        spnCantidad.setValue(1);
        refrescarCarrito();
    }

    private void quitar() {
        int fila = tablaCarrito.getSelectedRow();
        if (fila < 0) {
            Ui.error(this, "Selecciona una línea del carrito.");
            return;
        }
        carrito.remove(fila);
        refrescarCarrito();
    }

    private void refrescarCarrito() {
        modeloCarrito.setRowCount(0);
        BigDecimal total = BigDecimal.ZERO;
        for (DetalleVenta d : carrito) {
            Producto p = d.getProducto();
            modeloCarrito.addRow(new Object[]{p.getCodigo(), p.getNombre(), d.getCantidad(),
                Ui.dinero(p.getPrecio()), Ui.dinero(d.getSubtotal())});
            total = total.add(d.getSubtotal());
        }
        lblTotal.setText("Total: " + Ui.dinero(total));
    }

    private void registrar() {
        Usuario u = (Usuario) cboUsuario.getSelectedItem();
        if (u == null) {
            Ui.error(this, "Selecciona el cajero que registra la venta.");
            return;
        }
        if (carrito.isEmpty()) {
            Ui.error(this, "Agrega al menos un producto.");
            return;
        }
        try {
            int id = ventaDAO.registrar(u.getId(), carrito);
            carrito.clear();
            refrescarCarrito();
            recargarCombos();
            cargarHistorial();
            Ui.info(this, "Venta #" + id + " registrada correctamente.");
        } catch (SQLException ex) {
            Ui.error(this, Ui.mensajeSQL(ex));
            recargarCombos();
        }
    }

    private void cargarHistorial() {
        try {
            modeloVentas.setRowCount(0);
            modeloDetalle.setRowCount(0);
            for (Object[] f : ventaDAO.listar()) {
                modeloVentas.addRow(new Object[]{f[0], f[1], String.valueOf(f[2]),
                    Ui.dinero((BigDecimal) f[3])});
            }
        } catch (SQLException ex) {
            Ui.error(this, Ui.mensajeSQL(ex));
        }
    }

    private void cargarDetalle() {
        int fila = tablaVentas.getSelectedRow();
        modeloDetalle.setRowCount(0);
        if (fila < 0) {
            return;
        }
        try {
            int idVenta = (Integer) modeloVentas.getValueAt(fila, 0);
            for (Object[] f : ventaDAO.detalle(idVenta)) {
                modeloDetalle.addRow(new Object[]{f[0], f[1], f[2], Ui.dinero((BigDecimal) f[3])});
            }
        } catch (SQLException ex) {
            Ui.error(this, Ui.mensajeSQL(ex));
        }
    }

    private void anular() {
        int fila = tablaVentas.getSelectedRow();
        if (fila < 0) {
            Ui.error(this, "Selecciona una venta del historial.");
            return;
        }
        int idVenta = (Integer) modeloVentas.getValueAt(fila, 0);
        if (!Ui.confirmar(this, "¿Anular la venta #" + idVenta + "? El stock se devolverá a los productos.")) {
            return;
        }
        try {
            ventaDAO.anular(idVenta);
            cargarHistorial();
            recargarCombos();
        } catch (SQLException ex) {
            Ui.error(this, Ui.mensajeSQL(ex));
        }
    }
}
