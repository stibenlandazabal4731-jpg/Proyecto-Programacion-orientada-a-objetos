package vista;

import datos.UsuarioDAO;
import modelo.Usuario;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

/** CRUD de usuarios. */
public class FrmUsuarios extends JInternalFrame {

    private final UsuarioDAO dao = new UsuarioDAO();
    private List<Usuario> datos = new ArrayList<>();

    private final JTextField txtId = new JTextField();
    private final JTextField txtNombre = new JTextField(20);
    private final JTextField txtCorreo = new JTextField(20);
    private final JComboBox<String> cboRol = new JComboBox<>(
            new String[]{"Administrador", "Cajero", "Inventarios"});

    private final DefaultTableModel modelo = Ui.modelo("ID", "Nombre", "Correo", "Rol");
    private final JTable tabla = new JTable(modelo);

    public FrmUsuarios() {
        super("Gestión de usuarios", true, true, true, true);
        txtId.setEditable(false);
        cboRol.setEditable(true);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Datos del usuario"));
        Ui.fila(form, 0, "ID:", txtId);
        Ui.fila(form, 1, "Nombre:", txtNombre);
        Ui.fila(form, 2, "Correo:", txtCorreo);
        Ui.fila(form, 3, "Rol:", cboRol);

        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.getSelectionModel().addListSelectionListener(e -> {
            int fila = tabla.getSelectedRow();
            if (!e.getValueIsAdjusting() && fila >= 0 && fila < datos.size()) {
                mostrar(datos.get(fila));
            }
        });
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createTitledBorder("Listado"));

        JButton btnNuevo = new JButton("Nuevo");
        JButton btnGuardar = new JButton("Guardar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnRefrescar = new JButton("Refrescar");
        btnNuevo.addActionListener(e -> limpiar());
        btnGuardar.addActionListener(e -> guardar());
        btnEliminar.addActionListener(e -> eliminar());
        btnRefrescar.addActionListener(e -> cargar());
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 6));
        botones.add(btnNuevo);
        botones.add(btnGuardar);
        botones.add(btnEliminar);
        botones.add(btnRefrescar);

        add(form, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(botones, BorderLayout.SOUTH);
        setSize(640, 480);
        cargar();
    }

    private void cargar() {
        try {
            datos = dao.listar();
            modelo.setRowCount(0);
            for (Usuario u : datos) {
                modelo.addRow(new Object[]{u.getId(), u.getNombre(), u.getCorreo(), u.getRol()});
            }
        } catch (SQLException ex) {
            Ui.error(this, Ui.mensajeSQL(ex));
        }
    }

    private void mostrar(Usuario u) {
        txtId.setText(String.valueOf(u.getId()));
        txtNombre.setText(u.getNombre());
        txtCorreo.setText(u.getCorreo());
        cboRol.setSelectedItem(u.getRol());
    }

    private void limpiar() {
        tabla.clearSelection();
        txtId.setText("");
        txtNombre.setText("");
        txtCorreo.setText("");
        cboRol.setSelectedIndex(0);
        txtNombre.requestFocus();
    }

    private Usuario leer() {
        String nombre = txtNombre.getText().trim();
        String correo = txtCorreo.getText().trim();
        Object rolSel = cboRol.getSelectedItem();
        String rol = rolSel == null ? "" : rolSel.toString().trim();
        if (nombre.isEmpty() || nombre.length() > 50) {
            throw new IllegalArgumentException("El nombre es obligatorio y tiene máximo 50 caracteres.");
        }
        if (!correo.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$") || correo.length() > 100) {
            throw new IllegalArgumentException("Escribe un correo válido.");
        }
        if (rol.isEmpty() || rol.length() > 50) {
            throw new IllegalArgumentException("El rol es obligatorio (máx. 50 caracteres).");
        }
        Usuario u = new Usuario();
        u.setNombre(nombre);
        u.setCorreo(correo);
        u.setRol(rol);
        return u;
    }

    private void guardar() {
        try {
            Usuario u = leer();
            if (txtId.getText().isEmpty()) {
                dao.crear(u);
            } else {
                u.setId(Integer.parseInt(txtId.getText()));
                dao.actualizar(u);
            }
            limpiar();
            cargar();
        } catch (IllegalArgumentException ex) {
            Ui.error(this, ex.getMessage());
        } catch (SQLException ex) {
            Ui.error(this, Ui.mensajeSQL(ex));
        }
    }

    private void eliminar() {
        if (txtId.getText().isEmpty()) {
            Ui.error(this, "Selecciona un usuario de la tabla.");
            return;
        }
        if (!Ui.confirmar(this, "¿Eliminar al usuario " + txtNombre.getText() + "?")) {
            return;
        }
        try {
            dao.eliminar(Integer.parseInt(txtId.getText()));
            limpiar();
            cargar();
        } catch (SQLException ex) {
            Ui.error(this, Ui.mensajeSQL(ex));
        }
    }
}
