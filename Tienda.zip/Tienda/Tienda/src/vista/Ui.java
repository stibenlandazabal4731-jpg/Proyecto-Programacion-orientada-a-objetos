package vista;

import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.math.BigDecimal;
import java.sql.SQLException;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/** Utilidades compartidas por las ventanas. */
public final class Ui {

    private Ui() {
    }

    public static void fila(JPanel panel, int fila, String etiqueta, JComponent campo) {
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 6, 4, 6);
        g.anchor = GridBagConstraints.WEST;
        g.gridx = 0;
        g.gridy = fila;
        panel.add(new JLabel(etiqueta), g);
        g.gridx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1;
        panel.add(campo, g);
    }

    public static DefaultTableModel modelo(String... columnas) {
        return new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
    }

    public static void error(Component padre, String mensaje) {
        JOptionPane.showMessageDialog(padre, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void info(Component padre, String mensaje) {
        JOptionPane.showMessageDialog(padre, mensaje, "Información", JOptionPane.INFORMATION_MESSAGE);
    }

    public static boolean confirmar(Component padre, String mensaje) {
        return JOptionPane.showConfirmDialog(padre, mensaje, "Confirmar",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION;
    }

    public static String dinero(BigDecimal valor) {
        return String.format("$ %,.2f", valor);
    }

    /** Traduce los errores mas comunes de PostgreSQL a mensajes claros. */
    public static String mensajeSQL(SQLException e) {
        String msg = e.getMessage() == null ? "" : e.getMessage();
        if (msg.contains("UNIQUE constraint failed")) {
            return "Ya existe un registro con ese valor único (código o correo repetido).";
        }
        if (msg.contains("FOREIGN KEY constraint failed")) {
            return "No se puede eliminar: el registro está relacionado con ventas u otros datos.";
        }
        if (msg.contains("CHECK constraint failed")) {
            return "Algún valor no cumple las restricciones (precio y stock no pueden ser negativos).";
        }
        if (msg.contains("NOT NULL constraint failed")) {
            return "Falta un dato obligatorio.";
        }
        return msg;
    }
}
